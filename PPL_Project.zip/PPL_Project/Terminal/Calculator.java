import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridBagLayout;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JPanel;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.UIManager;
import java.awt.Font;
import java.util.*;
import java.awt.Window.Type;
import javax.swing.DefaultComboBoxModel;

public class Calculator implements ActionListener{
	public static  LinkedList<Op> ll;
	String constNames [] = {"cnst", " A", "b", "c"};
	static char tokSIGN, tokNO , tokOP, tokSTART;
	/* tokNO = carry on calculating no
	 * tokOP = expecting a unary + -
	 * tokSTART = expecting a binary operator or no
	 * tokSIGN = expecting a no.
	 */
	cnst c ;
	Solve solution;
	static char prev;
	double prevANS;
	private JFrame frmCalculator;
	private JTextField txt;
	private JButton btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9, btn_0;
	private JButton btn_open, btn_close, btn_sin, btn_cos, btn_tan, btn_log, btn_ln, btn_res, btn_ans, btn_E, btn_pow, btn_pt, btn_fact;
	private JButton btn_inv, btn_add, btn_sub, btn_mul, btn_div, btn_clr;
	
	private String screen ;// for textfield
	private String makeno;
	public Op item;
	private JButton btn_ON;
	JComboBox<String> cb;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculator window = new Calculator();
					window.frmCalculator.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public Calculator() {
		initialize();
	}

	
	private void initialize() {
		prevANS = 0;
		tokNO = 1;
		tokOP = 2;
		prev = tokOP;
		ll = new LinkedList<Op>();
		item = new Op();
		c = new cnst();
		makeno = "";
		solution = new Solve();
		screen = "Welcome Friend ! :-D ";
		frmCalculator = new JFrame();
		frmCalculator.setForeground(Color.WHITE);
		frmCalculator.setBackground(Color.WHITE);
		frmCalculator.setType(Type.POPUP);
		frmCalculator.setIconImage(Toolkit.getDefaultToolkit().getImage("icon.png"));
		frmCalculator.setTitle("Calculator");
		frmCalculator.getContentPane().setBackground(Color.WHITE);
		frmCalculator.setBounds(, 500, 800);
		frmCalculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{100, 100, 100, 100, 100};
		gridBagLayout.rowHeights = new int[]{100, 100, 100, 100, 100, 100, 100, 100};
		frmCalculator.getContentPane().setLayout(gridBagLayout);
		
		txt = new JTextField();
		txt.setForeground(new Color(255, 255, 224));
		txt.setBackground(new Color(0, 102, 51));
		txt.setEditable(false);
		txt.setFont(new Font("Comic Sans MS", Font.ITALIC, 27));
		txt.setHorizontalAlignment(SwingConstants.RIGHT);
		txt.setText(screen);
		GridBagConstraints gbc_txt = new GridBagConstraints();
		gbc_txt.gridwidth = 5;
		gbc_txt.insets = new Insets(2, 2, 2, 2);
		gbc_txt.fill = GridBagConstraints.BOTH;
		gbc_txt.gridx = 0;
		gbc_txt.gridy = 0;
		frmCalculator.getContentPane().add(txt, gbc_txt);
		txt.setColumns(10);
		
		btn_open = new JButton("(");
		btn_open.setForeground(new Color(0, 0, 139));
		btn_open.setBackground(UIManager.getColor("Button.background"));
		btn_open.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_open = new GridBagConstraints();
		gbc_btn_open.fill = GridBagConstraints.BOTH;
		gbc_btn_open.insets = new Insets(2, 2, 2, 2);
		gbc_btn_open.gridx = 0;
		gbc_btn_open.gridy = 1;
		frmCalculator.getContentPane().add(btn_open, gbc_btn_open);
		btn_open.addActionListener(this);
		
        btn_close = new JButton(")");
        btn_close.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
        btn_close.setIcon(null);
	//	btn_close.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_close = new GridBagConstraints();
		gbc_btn_close.fill = GridBagConstraints.BOTH;
		gbc_btn_close.insets = new Insets(2, 2, 2, 2);
		gbc_btn_close.gridx = 1;
		gbc_btn_close.gridy = 1;
		frmCalculator.getContentPane().add(btn_close, gbc_btn_close);
		btn_close.addActionListener(this);
		
		btn_pow = new JButton("^");
		btn_pow.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_pow = new GridBagConstraints();
		gbc_btn_pow.fill = GridBagConstraints.BOTH;
		gbc_btn_pow.insets = new Insets(2, 2, 2, 2);
		gbc_btn_pow.gridx = 2;
		gbc_btn_pow.gridy = 1;
		frmCalculator.getContentPane().add(btn_pow, gbc_btn_pow);
		btn_pow.addActionListener(this);
		
		btn_inv = new JButton("1/X");
		btn_inv.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_inv = new GridBagConstraints();
		gbc_btn_inv.fill = GridBagConstraints.BOTH;
		gbc_btn_inv.insets = new Insets(2, 2, 2, 2);
		gbc_btn_inv.gridx = 3;
		gbc_btn_inv.gridy = 1;
		frmCalculator.getContentPane().add(btn_inv, gbc_btn_inv);
		btn_inv.addActionListener(this);
		gbc_btn_inv.fill = GridBagConstraints.BOTH;
		gbc_btn_inv.insets = new Insets(2, 2, 2, 2);
		gbc_btn_inv.gridx = 4;
		gbc_btn_inv.gridy = 1;
		btn_inv.addActionListener(this);
		
		btn_ON = new JButton("ON");
		btn_ON.addActionListener(this);
		btn_ON.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_ON = new GridBagConstraints();
		gbc_btn_ON.fill = GridBagConstraints.BOTH;
		gbc_btn_ON.insets = new Insets(2, 2, 2, 2);
		gbc_btn_ON.gridx = 4;
		gbc_btn_ON.gridy = 1;
		frmCalculator.getContentPane().add(btn_ON, gbc_btn_ON);
		
		btn_sin = new JButton("sin");
		btn_sin.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_sin = new GridBagConstraints();
		gbc_btn_sin.fill = GridBagConstraints.BOTH;
		gbc_btn_sin.insets = new Insets(2, 2, 2, 2);
		gbc_btn_sin.gridx = 0;
		gbc_btn_sin.gridy = 2;
		frmCalculator.getContentPane().add(btn_sin, gbc_btn_sin);
		btn_sin.addActionListener(this);
		
		btn_cos = new JButton("cos");
		btn_cos.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_cos = new GridBagConstraints();
		gbc_btn_cos.fill = GridBagConstraints.BOTH;
		gbc_btn_cos.insets = new Insets(2, 2, 2, 2);
		gbc_btn_cos.gridx = 1;
		gbc_btn_cos.gridy = 2;
		frmCalculator.getContentPane().add(btn_cos, gbc_btn_cos);
		btn_cos.addActionListener(this);
		
		btn_tan = new JButton("tan");
		btn_tan.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_tan = new GridBagConstraints();
		gbc_btn_tan.fill = GridBagConstraints.BOTH;
		gbc_btn_tan.insets = new Insets(2, 2, 2, 2);
		gbc_btn_tan.gridx = 2;
		gbc_btn_tan.gridy = 2;
		frmCalculator.getContentPane().add(btn_tan, gbc_btn_tan);
		btn_tan.addActionListener(this);
		
		btn_log = new JButton("log");
		btn_log.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_log = new GridBagConstraints();
		gbc_btn_log.fill = GridBagConstraints.BOTH;
		gbc_btn_log.insets = new Insets(2, 2, 2, 2);
		gbc_btn_log.gridx = 3;
		gbc_btn_log.gridy = 2;
		frmCalculator.getContentPane().add(btn_log, gbc_btn_log);
		btn_log.addActionListener(this);
		
		btn_ln = new JButton("ln");
		btn_ln.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_ln = new GridBagConstraints();
		gbc_btn_ln.fill = GridBagConstraints.BOTH;
		gbc_btn_ln.insets = new Insets(2, 2, 2, 2);
		gbc_btn_ln.gridx = 4;
		gbc_btn_ln.gridy = 2;
		frmCalculator.getContentPane().add(btn_ln, gbc_btn_ln);
		btn_ln.addActionListener(this);
		
		btn_7 = new JButton("7");
		btn_7.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_7 = new GridBagConstraints();
		gbc_btn_7.fill = GridBagConstraints.BOTH;
		gbc_btn_7.insets = new Insets(2, 2, 2, 2);
		gbc_btn_7.gridx = 0;
		gbc_btn_7.gridy = 3;
		frmCalculator.getContentPane().add(btn_7, gbc_btn_7);
		btn_7.addActionListener(this);
		
		btn_8 = new JButton("8");
		btn_8.setBackground(UIManager.getColor("Button.background"));
		btn_8.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_8 = new GridBagConstraints();
		gbc_btn_8.fill = GridBagConstraints.BOTH;
		gbc_btn_8.insets = new Insets(2, 2, 2, 2);
		gbc_btn_8.gridx = 1;
		gbc_btn_8.gridy = 3;
		frmCalculator.getContentPane().add(btn_8, gbc_btn_8);
		btn_8.addActionListener(this);
		
		btn_9 = new JButton("9");
		btn_9.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_9 = new GridBagConstraints();
		gbc_btn_9.fill = GridBagConstraints.BOTH;
		gbc_btn_9.insets = new Insets(2, 2, 2, 2);
		gbc_btn_9.gridx = 2;
		gbc_btn_9.gridy = 3;
		frmCalculator.getContentPane().add(btn_9, gbc_btn_9);
		btn_9.addActionListener(this);
		
		btn_fact = new JButton("!");
		btn_fact.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_fact = new GridBagConstraints();
		gbc_btn_fact.fill = GridBagConstraints.BOTH;
		gbc_btn_fact.insets = new Insets(2, 2, 2, 2);
		gbc_btn_fact.gridx = 3;
		gbc_btn_fact.gridy = 3;
		frmCalculator.getContentPane().add(btn_fact, gbc_btn_fact);
		btn_fact.addActionListener(this);
		
		btn_clr = new JButton("CLR");
		btn_clr.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_clr = new GridBagConstraints();
		gbc_btn_clr.fill = GridBagConstraints.BOTH;
		gbc_btn_clr.insets = new Insets(2, 2, 2, 2);
		gbc_btn_clr.gridx = 4;
		gbc_btn_clr.gridy = 3;
		frmCalculator.getContentPane().add(btn_clr, gbc_btn_clr);
		btn_clr.addActionListener(this);
		
		btn_4 = new JButton("4");
		btn_4.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_4 = new GridBagConstraints();
		gbc_btn_4.fill = GridBagConstraints.BOTH;
		gbc_btn_4.insets = new Insets(2, 2, 2, 2);
		gbc_btn_4.gridx = 0;
		gbc_btn_4.gridy = 4;
		frmCalculator.getContentPane().add(btn_4, gbc_btn_4);
		btn_4.addActionListener(this);
		
		btn_5 = new JButton("5");
		btn_5.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_5 = new GridBagConstraints();
		gbc_btn_5.fill = GridBagConstraints.BOTH;
		gbc_btn_5.insets = new Insets(2, 2, 2, 2);
		gbc_btn_5.gridx = 1;
		gbc_btn_5.gridy = 4;
		frmCalculator.getContentPane().add(btn_5, gbc_btn_5);
		btn_5.addActionListener(this);
		
		btn_6 = new JButton("6");
		btn_6.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_6 = new GridBagConstraints();
		gbc_btn_6.fill = GridBagConstraints.BOTH;
		gbc_btn_6.insets = new Insets(2, 2, 2, 2);
		gbc_btn_6.gridx = 2;
		gbc_btn_6.gridy = 4;
		frmCalculator.getContentPane().add(btn_6, gbc_btn_6);
		btn_6.addActionListener(this);
		
		btn_mul = new JButton("*");
		btn_mul.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_mul = new GridBagConstraints();
		gbc_btn_mul.fill = GridBagConstraints.BOTH;
		gbc_btn_mul.insets = new Insets(2, 2, 2, 2);
		gbc_btn_mul.gridx = 3;
		gbc_btn_mul.gridy = 4;
		frmCalculator.getContentPane().add(btn_mul, gbc_btn_mul);
		btn_mul.addActionListener(this);
		
		btn_div = new JButton("/");
		btn_div.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_div = new GridBagConstraints();
		gbc_btn_div.fill = GridBagConstraints.BOTH;
		gbc_btn_div.insets = new Insets(2, 2, 2, 2);
		gbc_btn_div.gridx = 4;
		gbc_btn_div.gridy = 4;
		frmCalculator.getContentPane().add(btn_div, gbc_btn_div);
		btn_div.addActionListener(this);
		
		btn_1 = new JButton("1");
		btn_1.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_1 = new GridBagConstraints();
		gbc_btn_1.fill = GridBagConstraints.BOTH;
		gbc_btn_1.insets = new Insets(2, 2, 2, 2);
		gbc_btn_1.gridx = 0;
		gbc_btn_1.gridy = 5;
		frmCalculator.getContentPane().add(btn_1, gbc_btn_1);
		btn_1.addActionListener(this);
		
		btn_2 = new JButton("2");
		btn_2.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_2 = new GridBagConstraints();
		gbc_btn_2.fill = GridBagConstraints.BOTH;
		gbc_btn_2.insets = new Insets(2, 2, 2, 2);
		gbc_btn_2.gridx = 1;
		gbc_btn_2.gridy = 5;
		frmCalculator.getContentPane().add(btn_2, gbc_btn_2);
		btn_2.addActionListener(this);
		
		btn_3 = new JButton("3");
		btn_3.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_3 = new GridBagConstraints();
		gbc_btn_3.fill = GridBagConstraints.BOTH;
		gbc_btn_3.insets = new Insets(2, 2, 2, 2);
		gbc_btn_3.gridx = 2;
		gbc_btn_3.gridy = 5;
		frmCalculator.getContentPane().add(btn_3, gbc_btn_3);
		btn_3.addActionListener(this);
		
		btn_add = new JButton("+");
		btn_add.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_add = new GridBagConstraints();
		gbc_btn_add.fill = GridBagConstraints.BOTH;
		gbc_btn_add.insets = new Insets(2, 2, 2, 2);
		gbc_btn_add.gridx = 3;
		gbc_btn_add.gridy = 5;
		frmCalculator.getContentPane().add(btn_add, gbc_btn_add);
		btn_add.addActionListener(this);
		
		btn_sub = new JButton("-");
		btn_sub.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_sub = new GridBagConstraints();
		gbc_btn_sub.fill = GridBagConstraints.BOTH;
		gbc_btn_sub.insets = new Insets(2, 2, 2, 2);
		gbc_btn_sub.gridx = 4;
		gbc_btn_sub.gridy = 5;
		frmCalculator.getContentPane().add(btn_sub, gbc_btn_sub);
		btn_sub.addActionListener(this);
		
		btn_0 = new JButton("0");
		btn_0.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_0 = new GridBagConstraints();
		gbc_btn_0.fill = GridBagConstraints.BOTH;
		gbc_btn_0.insets = new Insets(2, 2, 2, 2);
		gbc_btn_0.gridx = 0;
		gbc_btn_0.gridy = 6;
		frmCalculator.getContentPane().add(btn_0, gbc_btn_0);
		btn_0.addActionListener(this);
		
		btn_pt = new JButton(".");
		btn_pt.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_pt = new GridBagConstraints();
		gbc_btn_pt.fill = GridBagConstraints.BOTH;
		gbc_btn_pt.insets = new Insets(2, 2, 2, 2);
		gbc_btn_pt.gridx = 1;
		gbc_btn_pt.gridy = 6;
		frmCalculator.getContentPane().add(btn_pt, gbc_btn_pt);
		btn_pt.addActionListener(this);
		
		btn_E = new JButton("E");
		btn_E.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_E = new GridBagConstraints();
		gbc_btn_E.fill = GridBagConstraints.BOTH;
		gbc_btn_E.insets = new Insets(2, 2, 2, 2);
		gbc_btn_E.gridx = 2;
		gbc_btn_E.gridy = 6;
		frmCalculator.getContentPane().add(btn_E, gbc_btn_E);
		btn_E.addActionListener(this);
		
		btn_ans = new JButton("ANS");
		btn_ans.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_ans = new GridBagConstraints();
		gbc_btn_ans.fill = GridBagConstraints.BOTH;
		gbc_btn_ans.insets = new Insets(2, 2, 2, 2);
		gbc_btn_ans.gridx = 3;
		gbc_btn_ans.gridy = 6;
		frmCalculator.getContentPane().add(btn_ans, gbc_btn_ans);
		btn_ans.addActionListener(this);
		
		btn_res = new JButton("=");
		btn_res.addActionListener(this);
		btn_res.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_btn_res = new GridBagConstraints();
		gbc_btn_res.insets = new Insets(2, 2, 2, 2);
		gbc_btn_res.fill = GridBagConstraints.BOTH;
		gbc_btn_res.gridx = 4;
		gbc_btn_res.gridy = 6;
		frmCalculator.getContentPane().add(btn_res, gbc_btn_res);
		
		cb = new JComboBox(constNames);
		cb.setModel(new DefaultComboBoxModel(new String[] {" Constant", " Pie", " Proton mass", " Neutron mass", " Electron mass", " Bohr Radius", " Planck constant", " Electron radius", " Rydberg constant", " Atomis mass unit", " Farady constant", " Elementary charge", " Avagadro constant", " Boltzman constant", " Molar volume(ideal)", " Speed of Light", " Electric constant", " Magnetic constant", " Gravitational acc. g", " Newtonian constant G"}));
		cb.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 25));
		GridBagConstraints gbc_cb = new GridBagConstraints();
		gbc_cb.gridwidth = 5;
		gbc_cb.fill = GridBagConstraints.BOTH;
		gbc_cb.insets = new Insets(0, 0, 0, 5);
		gbc_cb.gridx = 0;
		gbc_cb.gridy = 7;
		frmCalculator.getContentPane().add(cb, gbc_cb);
		cb.addActionListener(this); }	

	
	public void actionPerformed(ActionEvent e) {

		if(e.getSource() instanceof JComboBox) {
			double constant = 0;
        	String s = (String)cb.getSelectedItem();
        	if(s != " Constant"){
        		
	    		switch(s) {
	    		case " Pie":
	    			constant = 3.141592654;
	    			break;
	    			
	    		case " Proton mass":
	    			constant = 1.672621777E-27;
	    			break;
	    			
	    		case " Neutron mass":
	    			constant = 1.674927351E-27;
	    			break;
	    			
	    		case " Electron mass":
	    			constant = 9.01938291E-31;
	    			break;
	    			
	    		case " Bohr Radius":
	    			constant = 5.291772109E-11;
	    			break;
	    			
	    		case " Planck constant":
	    			constant = 6.62606957E-34;
	    			break;
	    			
	    		case " Electron radius":
	    			constant = 2.817940327E-15;
	    			break;
	    			
	    		case " Rydberg constant":
	    			constant = 10973731.57;
	    			break;
	    			
	    		case " Atomis mass unit":
	    			constant = 1.660538921E-27;
	    			break;
	    			
	    		case " Farady constant":
	    			constant = 96485.3365;
	    			break;
	    			
	    		case " Elementary charge":
	    			constant = 1.602176565E-19;
	    			break;
	    			
	    		case " Avagadro constant":
	    			constant = 6.02214129E23;
	    			break;
	    			
	    		case " Boltzman constant":
	    			constant = 1.3806488E-23;
	    			break;
	    			
	    		case " Molar volume(ideal)":
	    			constant = 0.022710953;
	    			break;
	    			
	    		case " Speed of Light":
	    			constant = 299792458;
	    			break;
	    			
	    		case " Electric constant":
	    			constant = 8.854187817E-12;
	    			break;
	    			
	    		case " Magnetic constant":
	    			constant = 0.000001256;
	    			break;
	    			
	    		case " Gravitational acc. g":
	    			constant = 9.80665;
	    			break;
	    			
	    		case " Newtonian constant G":
	    			constant = 6.672384E-11;
	    			break;
	    				
	    		}
	    		screen = screen + constant;
    			txt.setText(screen);
    			item.tag = cnst.tagNO;
    			item.no = constant;
    			item.attach();
    			prev = tokSTART;
        	}
        }
		String str = e.getActionCommand();
		if((str.equals("0")) || (str.equals("1")) || (str.equals("2")) || (str.equals("3")) || (str.equals("4")) || (str.equals("5")) || (str.equals("6")) || (str.equals("7")) || (str.equals("8")) || (str.equals("9"))){
			screen += str;
			txt.setText(screen);
			if(prev == tokOP) {
				makeno = str;
			}
			else if((prev == tokSIGN ) || (prev == tokNO)) {
				makeno += str;
			}
			prev = tokNO;
		}
		
		else if(str.equals("(")){
			screen += "(";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
				item.tag = cnst.tagMUL;
				item.attach();
			}
			item.tag = cnst.tagOPEN;
			item.attach();
			prev = tokOP;
		}
		
		else if(str.equals(")")){
			screen += ")";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue();
				
				item.attach();
			}
			item.tag = cnst.tagCLOSE;
			item.attach();
			prev = tokSTART;
		}
		
		else if(str.equals("sin")){
			screen += "sin(";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
				item.tag = cnst.tagMUL;
				item.attach();
			}
			item.tag = cnst.tagSIN;
			item.attach();
			item.tag = cnst.tagOPEN;
			item.attach();
			prev = tokOP;
		}
		
		else if(str.equals("cos")){
			screen += "cos(";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
				item.tag = cnst.tagMUL;
				item.attach();
			}
			item.tag = cnst.tagCOS;
			item.attach();
			item.tag = cnst.tagOPEN;
			item.attach();
			prev = tokOP;
		}
		
		else if(str.equals("tan")){
			screen += "tan(";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
				item.tag = cnst.tagMUL;
				item.attach();
			}
			item.tag = cnst.tagTAN;
			item.attach();
			item.tag = cnst.tagOPEN;
			item.attach();
			prev = tokOP;
		}
		
		else if(str.equals("log")){
			screen += "log(";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
				item.tag = cnst.tagMUL;
				item.attach();
			}
			item.tag = cnst.tagLOG;
			item.attach();
			item.tag = cnst.tagOPEN;
			item.attach();
			prev = tokOP;
		}
		
		else if(str.equals("ln")){
			screen += "ln(";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
				item.tag = cnst.tagMUL;
				item.attach();
			}
			item.tag = cnst.tagLN;
			item.attach();
			item.tag = cnst.tagOPEN;
			item.attach();
			prev = tokOP;
		}
		
		else if(str.equals("+")){
			screen += "+";
			txt.setText(screen);
			if(prev == tokOP) {
				makeno ="";
				prev = tokSIGN;
			}
			else if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
				System.out.println("Appending a no. " + (int)item.tag);
				
				item.tag = cnst.tagADD;
				item.attach();
				System.out.println("Appending a + sign " + (int)item.tag);
				prev = tokOP;

			}
			else {
				item.tag = cnst.tagADD;
				item.attach();
				System.out.println("Appending a + sign " + (int)item.tag);
				prev = tokOP;

			}
			
		}
		
		
		else if(str.equals("-")){
			screen += "-";
			txt.setText(screen);
			if(prev == tokOP){
				makeno = "-";
				prev = tokSIGN;
			}
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
				item.tag = cnst.tagSUB;
				item.attach();
				prev = tokOP;
			}
			
		}
		
		else if(str.equals("*")){
			screen += "*";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
			}
			item.tag = cnst.tagMUL;
			item.attach();
			prev = tokOP;
		}
		
		else if(str.equals("/")){
			screen += "/";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
			}
			item.tag = cnst.tagDIV;
			item.attach();
			prev = tokOP;
		}
		
		else if(str.equals("=")){
			System.out.println("EHGHHJDSGHJGDSHGDHSGHDGHJDGJSGDJHDG");
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				item.attach();
				System.out.println("I am in +");
			}
			for(int i = 0; i < ll.size(); i++){
				ll.get(i).show();
			}
			prevANS = solution.solvebb();
			screen = screen + "=" + prevANS;
			txt.setText(screen);
		}
		
		else if(str.equals("ANS")){
			screen += prevANS;
			txt.setText(screen);
			item.tag = cnst.tagNO;
			item.no = prevANS;
			item.attach();
			prev = tokSTART;
		}
		
		else if(str.equals("!")){
			screen += "!";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
			}
			item.tag = cnst.tagFACT;
			item.attach();
			prev = tokSTART;
		}
		
		else if(str.equals("CLR") || (str.equals("ON"))){
			screen = "";
			txt.setText(screen);
			
			makeno = "";
			prev = tokOP;
			ll.clear();
		}
		
		else if(str.equals("DEL")){
				
		}
		
		else if(str.equals("^")){
			screen += "^";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
			}
			item.tag = cnst.tagPOW;
			item.attach();
			prev = tokOP;
		}
		
		else if(str.equals(".")){
			screen += '.';
			txt.setText(screen);
			if((prev == tokOP) || (prev == tokSIGN)){
				makeno += "0.";
			}
			else {
				makeno += ".";
			}
			prev = tokNO;
		}
		
		else if(str.equals("E")) {
			// write this
			screen += 'E';
			txt.setText(screen);
			if((prev == tokOP) || (prev == tokSIGN)){
				makeno += "0E";
			}
			else {
				makeno += "E";
			}
			prev = tokNO;
		}
		
		else if(str.equals("1/X")){
			screen += "1/(";
			txt.setText(screen);
			if(prev == tokNO) {
				makeno += '\0';
				item.tag = cnst.tagNO;
				item.no = Double.valueOf(makeno).doubleValue(); 
				
				item.attach();
				item.tag = cnst.tagMUL;
				item.attach();
			}
			item.tag = cnst.tagINV;
			item.attach();
			item.tag = cnst.tagOPEN;
			item.attach();
			prev = tokOP;
		}
		System.out.println(makeno);
		for(int i = 0; i < ll.size(); i++){
			ll.get(i).show();
		}
	}
}
