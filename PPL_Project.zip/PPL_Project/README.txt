Name : Ms. Sayali Sambhaji Salunke

Class : SY COMP 

Batch : S2

Sub : Principles of Programming Languages Lab

Project Topic : Scientfic Calculator

> This is java code .

> This folder contains two files ,
	1. Eclipse
		Just copy the folder to your eclipse workplace and run, if you have already installed Eclipse .
		If not, you need to install or follow next option
	2. Terminal
		cd this folder in terminal or cmd
		javac *.java
		java Calculator
		and hence a window will appear

> Calculator does following operations ,
	Addition
	Substraction
	Division
	Multiplication
	Factorial
	Inverse
	log
	base 10
	ln base e
	power
	sin
	cos
	tan
> Feathures ,
	Solves mathematical equation considering BODMAS rule 
	Priority can be varied using brackets
	Mathematical constants value are inbuilt in this fordirect use
	Answer of previous operation is saved for consecutive calculations
	
> Logic
	1. When user presses a key , it detects which key has pressed.
	2. Subsequently builds a linked list of the equation.
	3. When = key is hit , It starts solving the equation. 
	4. Displays it and stores for furthur use.
	
