
public class Stk {
	
	static int MAX;
	int a [];
	int curr;
	
	
	void push(int number) {
		this.a[this.curr] = number;
		this.curr++;
	}
	
	
	int pop() {
		int x = this.a[this.curr - 1];
		this.curr--;
		return x;
	}
	
	
	Stk () {
		MAX = 128;
		a = new int [MAX];
		curr = 0;
	}
	
	
	Boolean empty() {
		if(this.curr == 0){
			return true;
		}
		return false;
	}
	
	
	Boolean full() {
		if(this.curr == MAX) {
			return true;
		}
		return false;
	}

	
}
