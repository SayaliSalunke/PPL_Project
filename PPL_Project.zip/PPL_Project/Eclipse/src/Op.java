
public class Op {
	char tag;
	double no;
	
	public Op() {
		tag = 0;
		no = 0.0;
	}
	void show() {
		System.out.println("tag  =  " + (int)tag + "\t no   =  " + no);
	}
	
	void attach() {
		Op at = new Op();
		at.tag = tag;
		at.no = no;
		Calculator.ll.addLast(at);
	}
	void attach(int i){
		Op at = new Op();
		at.tag = tag;
		at.no = no;
		Calculator.ll.add(i, at);
	}
}
