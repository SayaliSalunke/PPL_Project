
public class cnst {
	final public static char tagNO = 1, tagADD = 2, tagSUB = 3, tagDIV = 5, tagMUL = 4, tagSIN = 6;
	final public static char tagCOS = 7, tagTAN = 8, tagOPEN = 9, tagCLOSE = 10, tagFACT = 11, tagINV = 12;
	final public static char tagPOW = 13, tagLOG = 14, tagLN = 15;
	final public static double ERROR = -99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999.00;
}
