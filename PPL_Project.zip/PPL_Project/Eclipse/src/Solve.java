import java.util.Stack;

// yummy this the progrmm who is gonna solvr.......... from linkedlist 
public class Solve {
	Op show = new Op();
	double ans;
	public int size;
	public Solve() {
		ans = 0.0;
	}
	/* we assume that we know the position of star and end of the bracket */
	double solvebb() {
		System.out.println("Sayali Here in the solve with brackets ");
		size = Calculator.ll.size();
		System.out.println("Size + " + size);
		Stk s = new Stk();
		int i;
		Op keyOp = new Op();
		int open, close;
		do {
			open = 0;
			close = size - 1;
			for(i = 0; i < size; i++) {
				keyOp = Calculator.ll.get(i);
				if(keyOp.tag == cnst.tagOPEN) {
					if(!(s.full())) {
						s.push(i);
					}
					else 
						return cnst.ERROR;
				}
				else if(keyOp.tag == cnst.tagCLOSE) {
					close = i;
					if(!(s.empty()))
						open = s.pop();
					else 
						return cnst.ERROR;
					break;
				}
			}
			System.out.println("Open = " + open+"close = "+close);
			solvewb(open, close);
			for(int p = 0; p < Calculator.ll.size(); p++){
				Calculator.ll.get(p).show();
			}
			size = Calculator.ll.size();
		}while(size > 1);
		
		// you hav answer in the node now
		ans = Calculator.ll.get(0).no;
		return ans;
	}
	
	/* solving expression without brackets or brackets only at start and end */
	void solvewb(int open, int close) {
		int change = 0;
		int i;
		Op key = new Op();
		i = open;
		while(i <= close) {
			key = Calculator.ll.get(i);
			switch(key.tag) {
			
			case cnst.tagOPEN:
				change = open(i);
				break;
				
			case cnst.tagCLOSE:
				change = close(i);
				break;
				
			case cnst.tagSIN:
				change = sin(i);
				break;
				
			case cnst.tagCOS:
				change = cos(i);
				break;
				
			case cnst.tagTAN:
				change = tan(i);
				break;
				
			case cnst.tagFACT:
				change = fact(i);
				break;
			case cnst.tagINV:
				change = inv(i);
				break;
				
			case cnst.tagPOW:
				change = pow(i);
				break;
				
			case cnst.tagLOG:
				change = log(i);
				break;
				
			case cnst.tagLN:
				change = ln(i);
				break;
				
			}
			if(change != 0) {
				if(change == 1) {
					i = i + 1;
				}
				close = close - change;
				change = 0;
			}
			else
				i++;
		}
		// Now here you are where all unary are done only binary left like + - * / only
		solveBinary(open, close);
	}
	
	void solveBinary(int open, int close) {
		int i; 
		Op key = new Op();
		double n1, n2, ans = 0;
		while(open < close) {
			i = getHeavy(open, close);
			if( i == -1)
				break;
			n1 = Calculator.ll.get(i - 1).no;
			n2 = Calculator.ll.get(i + 1).no;
			key = Calculator.ll.get(i);
			switch(key.tag){
			case cnst.tagADD:
				System.out.println("ADDING IN THE SOLVEBINARY i = "+ i);
				ans = n1 + n2;
				break;
			
			case cnst.tagSUB:
				ans = n1 - n2;
				break;
			
			case cnst.tagMUL:
				ans = n1 * n2;
				break;
			
			case cnst.tagDIV:
				ans = n1 / n2;
				break;	
			}
			Calculator.ll.remove(i + 1);
			Calculator.ll.remove(i);
			Calculator.ll.remove(i - 1);
			
			key.tag = cnst.tagNO;
			key.no = ans;
			key.attach(i - 1);
			close = close - 2;
		}
	}
	
	/* Returns position of operator with highest priority if no operator than returns -1 */
	int getHeavy(int open, int close) {
		Op key = new Op();
		int i = open, pos = -1;
		char max = 1;
		while(i <= close) {
			key = Calculator.ll.get(i);
			if(key.tag > max) {
				max = key.tag;
				pos = i;
			}
			i++;
		}
		return pos;
	}
	
	// change gives no of nodes deleted in a operation 
	int sin(int index) {
		int nond = 0;//no of nodes deleted during operation
		Op temp = new Op();
		temp = Calculator.ll.get(index + 1);
		temp.no = Math.sin(temp.no);
		temp.tag = cnst.tagNO;
		Calculator.ll.remove(index + 1);
		nond++;
		Calculator.ll.remove(index);
		nond++;
		Calculator.ll.add(index, temp);
		nond--;
		return nond;
	}
	
	int cos(int index) {
		int nond = 0;//no of nodes deleted during operation
		Op temp = new Op();
		temp = Calculator.ll.get(index + 1);
		temp.no = Math.cos(temp.no);
		temp.tag = cnst.tagNO;
		Calculator.ll.remove(index + 1);
		nond++;
		Calculator.ll.remove(index);
		nond++;
		Calculator.ll.add(index, temp);
		nond--;
		return nond;
	}
	
	int tan(int index) {
		int nond = 0;//no of nodes deleted during operation
		Op temp = new Op();
		temp = Calculator.ll.get(index + 1);
		temp.no = Math.tan(temp.no);
		temp.tag = cnst.tagNO;
		Calculator.ll.remove(index + 1);
		nond++;
		Calculator.ll.remove(index);
		nond++;
		Calculator.ll.add(index, temp);
		nond--;
		return nond;
	}

	int pow(int index) {
		int nond = 0;//no of nodes deleted during operation
		Op tempb = new Op();
		Op tempd = new Op();
		
		tempd = Calculator.ll.get(index + 1);
		tempb = Calculator.ll.get(index - 1);
		tempb.no = Math.pow(tempb.no, tempd.no);
		tempb.tag = cnst.tagNO;
		Calculator.ll.remove(index + 1);
		nond++;
		Calculator.ll.remove(index);
		nond++;
		Calculator.ll.remove(index - 1);
		nond++;
		Calculator.ll.add(index - 1, tempb);
		nond--;
		return nond;
	}

	int log(int index) {
		int nond = 0;//no of nodes deleted during operation
		Op temp = new Op();
		temp = Calculator.ll.get(index + 1);
		temp.no = Math.log10(temp.no);
		temp.tag = cnst.tagNO;
		Calculator.ll.remove(index + 1);
		nond++;
		Calculator.ll.remove(index);
		nond++;
		Calculator.ll.add(index, temp);
		nond--;
		return nond;
	}
	
	int ln(int index) {
		int nond = 0;//no of nodes deleted during operation
		Op temp = new Op();
		temp = Calculator.ll.get(index + 1);
		temp.no = Math.log(temp.no);
		temp.tag = cnst.tagNO;
		Calculator.ll.remove(index + 1);
		nond++;
		Calculator.ll.remove(index);
		nond++;
		Calculator.ll.add(index, temp);
		nond--;
		return nond;
	}
	
	int inv(int index) {
		int nond = 0;//no of nodes deleted during operation
		Op temp = new Op();
		temp = Calculator.ll.get(index + 1);
		temp.no = 1 / temp.no ;
		temp.tag = cnst.tagNO;
		Calculator.ll.remove(index + 1);
		nond++;
		Calculator.ll.remove(index);
		nond++;
		Calculator.ll.add(index, temp);
		nond--;
		return nond;
	}

	int fact(int index) {
		int nond = 0;//no of nodes deleted during operation
		double fact = 1; // this  will be the result
		Op temp = new Op();
		temp = Calculator.ll.get(index - 1);
        for (int i = 1; i <= temp.no; i++) {
            fact *= i;
        }
        temp.no = fact;
		temp.tag = cnst.tagNO;
		Calculator.ll.remove(index);
		nond++;
		Calculator.ll.remove(index - 1);
		nond++;
		Calculator.ll.add(index - 1, temp);
		nond--;
		return nond;
	}

	int open(int index) {
		Calculator.ll.remove(index);
		return 1;
	}
	
	int close(int index) {
		Calculator.ll.remove(index);
		return 1;
	}
	
}
